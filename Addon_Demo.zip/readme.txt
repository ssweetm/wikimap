How to run this chrome extension.
1. Open a Google Chrome Browser window
2. Navigate to the extensions management page ( chrome://extensions )
3. Enable Developer mode in the top right corner.
4. Click on "Load Unpacked", select the Addon_Demo Folder and click OK
5. the extension should now be loaded and can be run by clicking on its icon in the top right of the browser
Note: the extension will require you to refresh any tabs that were open when the extension was loaded to run on them.
Also the extension will not run on chrome reserved pages (the new tab page, the extensions page, the setting page, etc)


Searching for a topic or term will display the appropriate dataset
Currently the addon supports one dataset and it will be displayed no matter what search criteria is used

